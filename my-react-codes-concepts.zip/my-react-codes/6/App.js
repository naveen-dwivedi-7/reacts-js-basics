import { useState } from 'react';

export default function FeedbackForm() {
  //Hooks can only be called at the top level of the component function. Here, the first isSent definition follows this rule, but the message definition is nested in a condition.
  
  const [isSent, setIsSent] = useState(false);
  const [message, setMessage] = useState('');

  if (isSent) {
    return <h1>Thank you!</h1>;
  } else {
    //const [message, setMessage] = useState(''); //wrong
    return (
      <form onSubmit={e => {
        e.preventDefault();
        alert(`Sending: "${message}"`);
        setIsSent(true);
      }}>
        <textarea
          placeholder="Message"
          value={message}
          onChange={e => setMessage(e.target.value)}
        />
        <br />
        <button type="submit">Send</button>
      </form>
    );
  }
}
