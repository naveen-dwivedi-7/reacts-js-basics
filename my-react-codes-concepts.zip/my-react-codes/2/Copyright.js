export default function Copyright({ year }) {
    return <p className='small'>©️ {year}</p>;
}
