import * as React from 'react';
import quotes from './quotes';
import FancyText from './FancyText';

export default function InspirationGenerator({ children }) {
    //set and update state of index
    //useState application 
    const [index, setIndex] = React.useState(0); 
    const quote = quotes[index];
    //arrow function next()
    const next = () => setIndex((index + 1) % quotes.length); //cyclic loop over qoutes array list

    return (
        <>
            <p>Your inspirational quote is:</p>
            <FancyText text={quote} />
            <button onClick={next}>Inspire me again</button>
            {children}
        </>
    );
}
