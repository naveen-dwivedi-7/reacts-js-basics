import './App.css';

export default function App({ name, isPacked }) {
  if (isPacked) {
    return null;
  }
  return <li className="item">{name}</li>;
}

export function PackingList() {
  return (
    <section>
      <h1>Sally Ride's Packing List</h1>
      <ul>
        <App
          isPacked={true}
          name="Space suit"
        />
        <App
          isPacked={true}
          name="Helmet with a golden leaf"
        />
        <App
          isPacked={false}
          name="Photo of Tam"
        />
      </ul>
    </section>
  );
}
