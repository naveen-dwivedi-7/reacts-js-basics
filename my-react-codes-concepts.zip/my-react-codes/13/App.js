//import logo from './logo.svg';
import './App.css';

const people = [
  'Creola Katherine Johnson: mathematician',
  'Mario José Molina-Pasquel Henríquez: chemist',
  'Mohammad Abdus Salam: physicist',
  'Percy Lavon Julian: chemist',
  'Subrahmanyan Chandrasekhar: astrophysicist'
];
export default function App(props) {
  return (
    <div className="App">
      <ul>{props.items}</ul>;
    </div>
  );
}

export function RenderingList() {
  const listItems = people.map((person) =>
    <li>{person}</li>
  );
  return (
    <App 
      items={listItems}
      />
  );
}
